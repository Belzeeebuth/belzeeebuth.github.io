'use strict';
// Persistent shell settings + per-app JSON storage.
//
// Settings channels:
//   settings:all                 -> full merged settings object
//   settings:get (key)           -> value at dotted key ('taskbar.align')
//   settings:set (key, value)    -> sets & persists; broadcasts 'settings:changed' {key, value, all}
//   settings:reset (key?)        -> restore default for key (or everything)
//   settings:setMany (patch, { reset })  -> applies { 'dotted.key': value, … } (and resets the keys in
//                                   opts.reset) atomically: one save, ONE 'settings:changed'
//                                   broadcast { key: '*', keys, value: all, all }
//   settings:defaults            -> the defaults (DEFAULTS + /etc/aurora/settings.json)
// Personalization keys are documented in docs/PERSONALIZATION.md.
// App storage channels (~/.config/aurora/apps/<appId>/<name>.json):
//   storage:get (appId, name, fallback)  -> stored JSON value or fallback
//   storage:set (appId, name, value)     -> true
//   storage:delete (appId, name)         -> true
const fs = require('fs');
const path = require('path');
const os = require('os');

const CONFIG_DIR = path.join(os.homedir(), '.config', 'aurora');
const FILE = path.join(CONFIG_DIR, 'settings.json');
const SYSTEM_FILE = '/etc/aurora/settings.json';

const DEFAULTS = {
  theme: 'dark', // 'light' | 'dark'
  accent: '#7fcbff', // '#rrggbb': the accent of the default finish and style (Halo + Nocturne, ice blue; core/finishes.js finishDefaults). The four Selene accents: #c9d3e6 silver, #6f8de6 night blue, #a58bf2 violet, #e9b566 amber (core/theme.js ACCENT_PRESETS)
  transparency: true,
  animations: true,
  wallpaper: 'builtin:halo-nocturne', // 'builtin:<id>' or absolute image path (each finish x style has its own: core/finishes.js finishDefaults)
  wallpaperFit: 'fill', // fill | fit | stretch | center | tile
  lang: null, // null -> follow system ($LANG); 'en' | 'fr'
  clock24h: null, // null -> locale default
  scale: 100, // display scale % (shell zoom)
  nightLight: false,
  nightLightStrength: 40,
  sounds: true,
  volume: 60,
  desktopIcons: true,
  desktopIconSize: 'medium',
  lockTimeout: 0, // minutes of inactivity before auto-lock, 0 = never
  taskbar: { align: 'center', autohide: false, showSearch: true, showTaskView: true, showWidgets: false },
  pinned: ['files', 'browser', 'mail', 'notepad', 'terminal', 'settings'],
  startPinned: [
    'browser', 'mail', 'files', 'settings', 'calculator', 'paint', 'notepad', 'terminal', 'media',
    'snipping', 'taskmgr', 'minesweeper', 'solitaire', 'snake', 'game2048', 'chess',
  ],
  notifications: { enabled: true, dnd: false, sounds: true },
  defaultApps: {},
  keyboardLayout: null,
  startShowRecent: true,
  showSeconds: false,
  // Settings app (apps/settings) — keys below are applied live by the shell or the backends:
  lockWallpaper: null, // lock screen picture: null = same as the desktop, 'builtin:<id>' or absolute image path
  multitasking: { snap: true, snapLayouts: true, snapBar: true, snapAssist: true, shake: false }, // features/snaplayouts.js (snapBar: layouts bar when dragging a window to the top)
  clipboard: { history: false }, // Win+V clipboard history (features/hotkeys.js)
  mouse: { speed: 0, leftHanded: false }, // pointer acceleration -1..1 and primary button (applied with xinput, main/ipc/locale.js)

  // ---- Personalization (docs/PERSONALIZATION.md). Area A — theme engine (core/theme.js):
  finish: 'halo', // finish (material of the whole shell): halo | prisme | sobre (core/finishes.js; <html data-finish>)
  tintFromWallpaper: true, // glass finishes: windows and panels take the wallpaper's tint (core/theme.js)
  style: 'nocturne', // visual style: nocturne | eclipse | clairdelune | contrast (older ids are migrated, see migrate())
  ambiance: null, // colour ambiance: null = the style's own (Nocturne cold, Éclipse neutral, Clair de lune warm) | cold | neutral | warm (core/theme.js ambianceOf, styleChoicePatch)
  autoTheme: { enabled: false, light: '07:00', dark: '19:00' }, // "Auto" mode: theme follows the time of day
  accentFromWallpaper: false, // pick the accent colour from the wallpaper
  transparencyLevel: 50, // 0 opaque … 50 Windows 11 look … 100 most see-through (windows, flyouts, taskbar)
  blur: 50, // blur intensity 0–100 (acrylic surfaces + Mica)
  cornerRadius: 100, // rounded-corner intensity, % of the style's radii (0–200)
  fontFamily: 'inter', // inter | system | noto-sans | dejavu-sans | liberation-sans | noto-serif | dejavu-serif | cascadia | unifont
  textScale: 100, // text size % (80–150), independent of the UI scale
  reducedMotion: false, // implies animations off + no animated wallpaper
  appThemes: {}, // { [appId]: { theme: 'system'|'light'|'dark', accent: null|'#rrggbb' } }
  // Area B1 — wallpaper engine (core/features/wallpaper.js, core/wallpaper/):
  wallpaperMode: 'static', // static (picture / solid colour) | animated | dynamic | slideshow
  // effect: aurora | bloom | fluid | bokeh | starfield | waves; speed / intensity 0–100; fps 15 | 30
  animatedWallpaper: { id: 'aurora', speed: 50, intensity: 50, fps: 30, pauseOnMaximized: true },
  // source: time (time of day) | weather (time of day + weather overlay); set: bloom | dunes | lake;
  // location: null (fixed 07:00–19:00 day) | { name, lat, lon }; followTheme: light from sunrise to sunset
  dynamicWallpaper: { source: 'time', set: 'lake', location: null, followTheme: false },
  slideshow: { folder: null, interval: 30, shuffle: true }, // folder null = the built-in pictures; interval in minutes
  lockScreen: { mode: 'picture', effect: 'aurora' }, // picture (lockWallpaper, null = same as the desktop) | spotlight | animated
  // Area B2 — Start (core/start.js) + Focus mode (core/features/focus.js); taskbar.* additions are merged into `taskbar` below:
  // layout: default | morePins | moreRecommended | list; background: acrylic | solid | accent | wallpaper;
  // folders: shortcuts next to the power button (documents, downloads, music, pictures, videos, files, settings, home, network);
  // groups: app folders in Pinned [{ id: 'g-…', name, apps: [appId] }]
  // showRecentApps / showMostUsed: apps in Recommended (recently added for a week / launched most)
  start: { layout: 'default', background: 'acrylic', folders: [], groups: [], showRecentApps: true, showMostUsed: false },
  // active is runtime state (never in profiles; a new session starts with it off); dimLevel 0–100; duration in minutes (0 = until off)
  // endsAt (ms, 0 = until turned off) and prevDnd (Do not disturb before the session) are runtime state too: a session
  // survives a restart of the shell until endsAt; hideIcons fades the desktop icons
  focusMode: { active: false, hideNotifications: true, dimDesktop: true, dimLevel: 40, hideIcons: false, simplifyTaskbar: true, duration: 0, endsAt: 0, prevDnd: null },
  // Area B3 — packs (core/packs.js, core/sounds.js) + input (core/shortcuts.js, features/hotkeys.js, features/snaplayouts.js):
  cursorPack: 'default', // default (system) | classic | midnight | accent | large | highvis | retro
  cursorSize: 100, // 100–300 (%): size of the pointer (the system pack is drawn as "Selene light" when > 100)
  iconPack: 'auto', // auto (follows the finish: halo, prisme, sobre -> selene) | halo | prisme | selene (the apps' own icons; 'fluent' before the redesign) | tiles | accent | graphite | mono | outline | glass | retro
  soundPack: 'aurora', // aurora | chimes | retro | soft | silent
  soundEvents: { notification: null, startup: null, shutdown: null }, // null = pack sound, 'none' = silent, '<pack>.<sound>', '/abs/file.ogg'
  soundVolume: 100, // 0–100: volume of the system sounds (multiplies every pack sound and sound file)
  startupSound: true, // play the startup sound when the session starts
  snapPresets: [], // [{ id, name, zones: [{ x, y, w, h }] }] (fractions of the work area)
  snapLayouts: null, // null = the six Windows 11 layouts then every preset; else the ordered ids shown (features/snaplayouts.js)
  shortcuts: {}, // { [actionId]: 'Super+K' | null } — overrides of core/shortcuts.js SHORTCUTS (null = turned off); 'app:<appId>' = open an app
};
// Personalization keys of the taskbar (Area A: color/opacity; Area B2: the rest), merged into DEFAULTS.taskbar.
Object.assign(DEFAULTS.taskbar, {
  color: null, // null = theme default | 'accent' | '#rrggbb'
  opacity: null, // null = follows transparencyLevel | 0–100
  size: 'medium', // small | medium | large
  position: 'bottom', // bottom | top | left | right
  showLabels: false, // app names next to the icons (horizontal taskbars)
  combine: 'always', // always | whenFull | never (one button per window)
  widgets: [], // tray mini widgets: 'weather' | 'cpu' | 'memory' | 'network'
  search: null, // null = follows showSearch | 'hidden' | 'icon' | 'box'
  tray: { network: true, volume: true, battery: true }, // status icons shown next to the clock
  badges: true, // unread-notification counts on app buttons
  widgetsPos: 'auto', // auto (start when centered, end when left-aligned) | start | inline (after Task view) | end (before the tray)
  hideDelay: 600, // ms an auto-hidden taskbar stays after the pointer leaves it
});

function isObj(v) {
  return v && typeof v === 'object' && !Array.isArray(v);
}

// Keys that would reach Object.prototype through setPath / delete (prototype pollution of the main process).
const UNSAFE_KEYS = new Set(['__proto__', 'constructor', 'prototype']);
/** A dotted settings key that is safe to walk: non-empty segments, no prototype names. */
function validKey(key) {
  return typeof key === 'string' && key.length > 0 && key.length <= 200 && key.split('.').every((p) => p && !UNSAFE_KEYS.has(p));
}

function deepMerge(a, b) {
  if (!isObj(b)) return b === undefined ? a : b;
  const out = { ...(isObj(a) ? a : {}) };
  for (const [k, v] of Object.entries(b)) {
    if (UNSAFE_KEYS.has(k)) continue;
    out[k] = isObj(v) && isObj(out[k]) ? deepMerge(out[k], v) : v;
  }
  return out;
}

function readJson(file, fallback) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    return fallback;
  }
}

// ENOSPC-safe: the new content goes to a temp file first; on any error (disk full, quota…) the temp file is removed
// and the old file stays as it was. Throws the original error (err.code 'ENOSPC').
function writeJsonAtomic(file, value) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = `${file}.${process.pid}.tmp`;
  try {
    fs.writeFileSync(tmp, JSON.stringify(value, null, 2));
    fs.renameSync(tmp, file);
  } catch (err) {
    try {
      fs.unlinkSync(tmp);
    } catch {}
    throw err;
  }
}

// ---- robustness (track "robust"): last-good backup of settings.json, restored on a parse error.
// settings.json.last-good = the file as it was at the last sign-in where it parsed. A file that does not parse
// (crash during a write by an older release, disk full, hand edit) is kept as settings.json.corrupt and replaced by
// the backup (or by the defaults); `recovered` tells the shell to say so once (core/features/robust.js).
function loadUserSettings(file) {
  const backup = `${file}.last-good`;
  let text;
  try {
    text = fs.readFileSync(file, 'utf8');
  } catch {
    return { user: {}, recovered: null };
  }
  try {
    const user = JSON.parse(text);
    if (!isObj(user)) throw new Error('not an object');
    try {
      if (!fs.existsSync(backup) || fs.readFileSync(backup, 'utf8') !== text) writeTextAtomic(backup, text);
    } catch (err) {
      console.error('[settings] backup not saved:', err.message);
    }
    return { user, recovered: null };
  } catch (err) {
    console.error(`[settings] ${file} is unreadable (${err.message}); restoring the last good copy`);
  }
  try {
    fs.copyFileSync(file, `${file}.corrupt`);
  } catch {}
  let user = null;
  try {
    user = JSON.parse(fs.readFileSync(backup, 'utf8'));
  } catch {}
  const recovered = isObj(user) ? 'backup' : 'defaults';
  if (!isObj(user)) user = {};
  try {
    writeJsonAtomic(file, user);
  } catch (err) {
    console.error('[settings] restored settings not saved:', err.message);
  }
  return { user, recovered };
}
function writeTextAtomic(file, text) {
  const tmp = `${file}.${process.pid}.tmp`;
  try {
    fs.writeFileSync(tmp, text);
    fs.renameSync(tmp, file);
  } catch (err) {
    try {
      fs.unlinkSync(tmp);
    } catch {}
    throw err;
  }
}
// Safe mode (main/lib/robust.js state.safeMode): the user's look is ignored (not deleted): finish Sobre, default
// style / wallpaper, no packs, no animated wallpaper. « Réinitialiser l'apparence » resets exactly these keys.
const SAFE_LOOK_KEYS = [
  'finish', 'style', 'ambiance', 'accent', 'wallpaper', 'wallpaperFit', 'wallpaperMode', 'animatedWallpaper', 'dynamicWallpaper',
  'slideshow', 'lockScreen', 'lockWallpaper', 'tintFromWallpaper', 'accentFromWallpaper', 'transparencyLevel', 'blur', 'cornerRadius',
  'fontFamily', 'appThemes', 'cursorPack', 'cursorSize', 'iconPack', 'soundPack', 'soundEvents', 'autoTheme', 'taskbar.color', 'taskbar.opacity',
];
function safeLook(base) {
  const look = {};
  for (const k of SAFE_LOOK_KEYS) setPath(look, k, structuredClone(getPath(base, k) ?? null));
  Object.assign(look, { finish: 'sobre', style: 'nocturne', ambiance: null, accent: '#c9d3e6', wallpaper: 'builtin:nocturne', wallpaperMode: 'static', iconPack: 'auto', cursorPack: 'default' });
  look.autoTheme = { ...(look.autoTheme || {}), enabled: false };
  return look;
}

function getPath(obj, key) {
  if (!key) return obj;
  return key.split('.').reduce((o, k) => (o == null ? undefined : o[k]), obj);
}

function setPath(obj, key, value) {
  if (!validKey(key)) return;
  const parts = key.split('.');
  let o = obj;
  for (let i = 0; i < parts.length - 1; i++) {
    if (!Object.prototype.hasOwnProperty.call(o, parts[i]) || !isObj(o[parts[i]])) o[parts[i]] = {};
    o = o[parts[i]];
  }
  o[parts[parts.length - 1]] = value;
}

/** Remove a user override (dotted key); never walks into inherited properties. */
function deletePath(obj, key) {
  if (!validKey(key)) return;
  const parts = key.split('.');
  let o = obj;
  for (let i = 0; i < parts.length - 1; i++) {
    if (!isObj(o) || !Object.prototype.hasOwnProperty.call(o, parts[i])) return;
    o = o[parts[i]];
  }
  if (isObj(o)) delete o[parts[parts.length - 1]];
}

function safeName(s) {
  return String(s).replace(/[^a-zA-Z0-9._-]/g, '_').slice(0, 80) || '_';
}

// Values saved by older releases (redesign of 2026-10): the Windows-like styles become Nocturne (High
// contrast stays), an unknown style too; the 'fluent' icon pack is now 'selene'. Returns true when it changed
// something. Used on the user file, on /etc/aurora/settings.json and by core/profiles.js for saved profiles.
const STYLE_IDS = ['nocturne', 'eclipse', 'clairdelune', 'contrast'];
const AMBIANCE_IDS = ['cold', 'neutral', 'warm'];
const FINISH_IDS = ['halo', 'prisme', 'sobre'];
function migrate(obj) {
  if (!isObj(obj)) return false;
  let changed = false;
  if ('finish' in obj && !FINISH_IDS.includes(obj.finish)) {
    delete obj.finish;
    changed = true;
  }
  if ('style' in obj && !STYLE_IDS.includes(obj.style)) {
    obj.style = 'nocturne';
    changed = true;
  }
  if ('ambiance' in obj && !AMBIANCE_IDS.includes(obj.ambiance)) {
    delete obj.ambiance;
    changed = true;
  }
  if (obj.iconPack === 'fluent') {
    obj.iconPack = 'selene';
    changed = true;
  }
  // Wallpapers of the Windows-like set (removed in the redesign) -> the Nocturne picture / the lake set.
  for (const k of ['wallpaper', 'lockWallpaper']) {
    if (typeof obj[k] === 'string' && RETIRED_WALLPAPERS.has(obj[k])) {
      obj[k] = 'builtin:nocturne';
      changed = true;
    }
  }
  if (isObj(obj.dynamicWallpaper) && RETIRED_DYNAMIC_SETS.has(obj.dynamicWallpaper.set)) {
    obj.dynamicWallpaper.set = 'lake';
    changed = true;
  }
  return changed;
}
const RETIRED_WALLPAPERS = new Set(['builtin:bloom', 'builtin:glow', 'builtin:flow', 'builtin:sunrise', 'builtin:aurora', 'builtin:dunes']);
const RETIRED_DYNAMIC_SETS = new Set(['bloom']);

// Finishes (2026-10-12): a settings file written before them never chose one, so it gets the default finish, Halo.
// Its accent and wallpaper move along when they are still the Selene ("Sobre") defaults of its style (the same
// follow rule as core/theme.js finishChoicePatch; table = core/finishes.js finishDefaults). Then 'finish' is
// written, so this runs once. A file without any look key (new user) needs nothing: DEFAULTS apply.
const SOBRE_DEFAULTS = {
  nocturne: { accent: '#c9d3e6', wallpaper: 'builtin:nocturne' },
  eclipse: { accent: '#e9b566', wallpaper: 'builtin:eclipse' },
  clairdelune: { accent: '#a58bf2', wallpaper: 'builtin:clairdelune' },
};
const HALO_DEFAULTS = {
  nocturne: { accent: '#7fcbff', wallpaper: 'builtin:halo-nocturne' },
  eclipse: { accent: '#ffb547', wallpaper: 'builtin:halo-eclipse' },
  clairdelune: { accent: '#b5367f', wallpaper: 'builtin:halo-clairdelune' },
};
const LOOK_KEYS = ['style', 'accent', 'wallpaper', 'ambiance', 'theme', 'iconPack'];
function migrateFinish(obj) {
  if (!isObj(obj) || 'finish' in obj || !LOOK_KEYS.some((k) => k in obj)) return false;
  const style = SOBRE_DEFAULTS[obj.style] ? obj.style : 'nocturne';
  const same = (a, b) => String(a ?? '').toLowerCase() === b;
  if ('accent' in obj && same(obj.accent, SOBRE_DEFAULTS[style].accent)) obj.accent = HALO_DEFAULTS[style].accent;
  if ('wallpaper' in obj && same(obj.wallpaper, SOBRE_DEFAULTS[style].wallpaper)) obj.wallpaper = HALO_DEFAULTS[style].wallpaper;
  if (obj.iconPack === 'selene') delete obj.iconPack; // the old default: now 'auto' (follows the finish)
  obj.finish = 'halo';
  return true;
}

module.exports = function register(api) {
  const system = readJson(SYSTEM_FILE, {});
  migrate(system);
  const base = deepMerge(DEFAULTS, system);
  // user overrides only (so new defaults reach existing users)
  const robust = require('../lib/robust');
  const loaded = loadUserSettings(FILE);
  let user = loaded.user;
  if (loaded.recovered) robust.state.settingsRecovered = loaded.recovered;
  if ([migrate(user), migrateFinish(user)].some(Boolean)) {
    try {
      writeJsonAtomic(FILE, user);
    } catch (err) {
      console.error('[settings] migration not saved', err);
    }
  }
  const merged = () => (robust.state.safeMode ? deepMerge(deepMerge(base, user), safeLook(base)) : deepMerge(base, user));
  let saveTimer = null;
  const save = () => {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => {
      try {
        writeJsonAtomic(FILE, user);
        if (robust.state.saveFailed) {
          robust.state.saveFailed = null;
          delete robust.state.acked.save;
        }
      } catch (err) {
        console.error('[settings] save failed', err);
        // Disk full (or read-only home): the previous file is intact; the shell tells the user once.
        if (!robust.state.saveFailed) {
          robust.state.saveFailed = { code: err.code || 'EFAIL', at: Date.now() };
          api.robust?.changed?.();
        }
      }
    }, 150);
  };

  // Main-process access for other backend modules (e.g. locale:setKeyboard persists keyboardLayout).
  api.settings = {
    get: (key) => getPath(merged(), key),
    set: (key, value) => {
      if (!validKey(key)) throw api.error('Invalid settings key', 'EINVAL');
      setPath(user, key, value);
      save();
      const all = merged();
      api.broadcast('settings:changed', { key, value: getPath(all, key), all });
      return getPath(all, key);
    },
  };

  api.handle('settings:all', () => merged());
  api.handle('settings:defaults', () => base);
  api.handle('settings:get', (key) => getPath(merged(), key));
  api.handle('settings:set', (key, value) => {
    if (!validKey(key)) throw api.error('Invalid settings key', 'EINVAL');
    setPath(user, key, value);
    save();
    const all = merged();
    api.broadcast('settings:changed', { key, value: getPath(all, key), all });
    return getPath(all, key);
  });
  // Several keys at once (profiles, the Theme designer): one save, one broadcast.
  api.handle('settings:setMany', (patch, opts = {}) => {
    if (!isObj(patch)) throw api.error('Invalid settings patch', 'EINVAL');
    const reset = Array.isArray(opts?.reset) ? opts.reset : [];
    const keys = [];
    for (const key of [...Object.keys(patch), ...reset]) {
      if (!validKey(key)) throw api.error(`Invalid settings key ${String(key).slice(0, 80)}`, 'EINVAL');
    }
    for (const key of reset) {
      deletePath(user, key);
      keys.push(key);
    }
    for (const [key, value] of Object.entries(patch)) {
      setPath(user, key, value);
      if (!keys.includes(key)) keys.push(key);
    }
    save();
    const all = merged();
    api.broadcast('settings:changed', { key: '*', keys, value: all, all });
    return all;
  });
  api.handle('settings:reset', (key) => {
    if (!key) user = {};
    else if (!validKey(key)) throw api.error('Invalid settings key', 'EINVAL');
    else deletePath(user, key);
    save();
    const all = merged();
    api.broadcast('settings:changed', { key: key || '*', value: key ? getPath(all, key) : all, all });
    return all;
  });

  const storeFile = (appId, name) => path.join(CONFIG_DIR, 'apps', safeName(appId), `${safeName(name)}.json`);
  api.handle('storage:get', (appId, name, fallback = null) => readJson(storeFile(appId, name), fallback));
  api.handle('storage:set', (appId, name, value) => {
    writeJsonAtomic(storeFile(appId, name), value);
    return true;
  });
  api.handle('storage:delete', (appId, name) => {
    try {
      fs.unlinkSync(storeFile(appId, name));
    } catch {}
    return true;
  });
  api.handle('storage:dir', (appId) => {
    const d = path.join(CONFIG_DIR, 'apps', safeName(appId));
    fs.mkdirSync(d, { recursive: true });
    return d;
  });
};

module.exports.DEFAULTS = DEFAULTS;
module.exports.migrate = migrate;
module.exports.migrateFinish = migrateFinish;
module.exports.writeJsonAtomic = writeJsonAtomic;
module.exports.loadUserSettings = loadUserSettings;
module.exports.SAFE_LOOK_KEYS = SAFE_LOOK_KEYS;
module.exports.safeLook = safeLook;
