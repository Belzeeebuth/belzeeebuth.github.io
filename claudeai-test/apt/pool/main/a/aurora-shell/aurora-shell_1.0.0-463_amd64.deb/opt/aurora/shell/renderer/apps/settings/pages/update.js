// Settings > Updates (Mises à jour): check (apt-get update + simulation), install (apt-get upgrade with live
// progress from APT's status fd), update history (/var/log/apt/history.log).
// « Microprogrammes » (fwupd, main/ipc/firmware.js): firmware:status / firmware:refresh (« Rechercher »), the update
// itself through the UAC prompt (aurora-admin firmware-update <40 hex device id>); keep-plugged-in warning, restart
// offered when fwupd says one is needed; the section is hidden when fwupd sees no updatable device.
import { parseAptSimulation, parseAptStatus, parseAptHistory } from '../lib/parse.js';
import { groupSelene } from '../lib/selene-updates.js';

// Survives page changes while the Settings window is open (an install keeps running in the background).
const state = { phase: null, packages: null, progress: null, step: '', error: null, reboot: false, lastCheck: null, loaded: false };
const listeners = new Set();
const emit = () => listeners.forEach((fn) => fn());

async function loadSaved(pc) {
  if (state.loaded) return;
  state.loaded = true;
  const saved = await pc.storage.get('update-state', null).catch(() => null);
  if (saved) {
    state.lastCheck = saved.lastCheck || null;
    state.packages = Array.isArray(saved.packages) ? saved.packages : null;
    state.reboot = !!saved.reboot;
  }
}
const persist = (pc) => pc.storage.set('update-state', { lastCheck: state.lastCheck, packages: state.packages, reboot: state.reboot }).catch(() => {});

// ---- BEGIN Selene self-updates (docs/UPDATES.md, main/ipc/selene-update.js) ----
// Selene's packages are listed as one « Selene x.y.z » entry; after a new aurora-shell (or Electron) is installed the
// page offers « Redémarrer la session » (sign out and back in: the running shell is the old version until then).
const selene = { status: null };
async function seleneLoad(pc) {
  selene.status = (await pc.tryInvoke('selene:status')) || null;
  emit();
}
function seleneRow(pc, s) {
  const { h, t } = pc;
  return h(
    'div',
    { class: 'st-pkg st-pkg-selene' },
    h('div', { class: 'row', style: { gap: '8px' } }, h('span', { class: 'body-strong' }, s.electron ? t('update.selene.nameElectron', { version: s.version }) : t('update.selene.name', { version: s.version })), s.security ? h('span', { class: 'st-pill accent' }, t('update.security')) : null),
    h('span', { class: 'caption text-2' }, s.electron ? t('update.selene.descElectron') : t('update.selene.desc')),
    h('span', { class: 'caption text-2' }, s.from ? t('update.fromTo', { from: s.from }) : t('update.newPackage')),
  );
}
function seleneRestart(pc) {
  if (!selene.status?.restartNeeded) return null;
  const { t, kit } = pc;
  return kit.infobar({ kind: 'info', title: t('update.selene.restartTitle'), message: t('update.selene.restartDesc'), className: 'st-selene-restart', action: kit.button(t('update.selene.restart'), () => pc.shell.logout().catch(pc.toastError), { primary: true, icon: 'arrow_clockwise' }) });
}
// ---- END Selene self-updates ----

// ---- BEGIN firmware (fwupd) ----
const fw = { status: null, loading: null, refreshing: false, updating: null, error: null, reboot: false, done: new Set() };
async function fwLoad(pc) {
  if (fw.loading) return fw.loading;
  fw.loading = pc
    .tryInvoke('firmware:status')
    .then((st) => {
      fw.status = st || { available: false, devices: [], updates: [] };
      if (st?.pendingReboot) fw.reboot = true;
    })
    .finally(() => {
      fw.loading = null;
      emit();
    });
  return fw.loading;
}
async function fwRefresh(pc) {
  if (fw.refreshing || fw.updating) return;
  fw.refreshing = true;
  fw.error = null;
  emit();
  try {
    fw.status = (await pc.api.invoke('firmware:refresh')) || fw.status;
    if (fw.status?.pendingReboot) fw.reboot = true;
  } catch (err) {
    fw.error = err.message;
  }
  fw.refreshing = false;
  emit();
}
async function fwUpdate(pc, u) {
  if (fw.updating || fw.refreshing) return;
  fw.updating = u.deviceId;
  fw.error = null;
  emit();
  try {
    const out = await pc.runAdmin('firmware-update', [u.deviceId], 'update.fw.reason', { name: u.deviceName, version: u.to });
    const reboot = /^reboot-required$/m.test(out || '') || !!u.needsReboot;
    if (reboot) fw.reboot = true;
    fw.done.add(u.deviceId);
    pc.shell.notify({ title: pc.t('update.fw.doneTitle', { name: u.deviceName }), body: reboot ? pc.t('update.fw.doneReboot') : pc.t('update.fw.doneBody'), appId: 'settings' });
  } catch (err) {
    if (err.code !== 'ECANCELED') fw.error = pc.t('update.fw.failed', { name: u.deviceName, msg: err.message });
  }
  fw.updating = null;
  await fwLoad(pc);
}
function fwSection(pc) {
  const { h, t, kit } = pc;
  const st = fw.status;
  // Hidden while loading, without fwupd, and when fwupd sees no device it can update.
  if (!st || !st.available || !st.devices?.length) return null;
  const ups = (st.updates || []).filter((u) => !fw.done.has(u.deviceId));
  const busy = !!fw.updating || fw.refreshing;
  const fmtSize = (n) => (n ? (n >= 1e6 ? `${(n / 1e6).toLocaleString(pc.lang === 'fr' ? 'fr-FR' : 'en-US', { maximumFractionDigits: 1 })} ${pc.lang === 'fr' ? 'Mo' : 'MB'}` : `${Math.max(1, Math.round(n / 1e3))} ${pc.lang === 'fr' ? 'Ko' : 'KB'}`) : '');
  const rows = [
    kit.row({
      icon: 'cpu',
      title: fw.refreshing ? t('update.fw.checking') : ups.length ? t('update.fw.available', { count: ups.length }) : t('update.fw.upToDate'),
      desc: t('update.fw.desc', { count: st.devices.length }),
      className: 'st-fw-head',
      control: kit.button(t('update.fw.check'), () => fwRefresh(pc), { icon: 'arrow_sync', disabled: busy, className: 'st-fw-check' }),
    }),
  ];
  for (const u of ups) {
    const updating = fw.updating === u.deviceId;
    const control = updating
      ? h('div', { class: 'row st-fw-busy', style: { gap: '8px' } }, h('span', { class: 'spinner small' }), h('span', { class: 'caption text-2' }, t('update.fw.updating')))
      : kit.button(t('update.fw.install'), () => fwUpdate(pc, u), { primary: true, disabled: busy, className: 'st-fw-install' });
    rows.push(
      kit.expander({
        icon: 'circuitry',
        title: u.deviceName,
        desc: [u.vendor, u.from && u.to ? t('update.fw.fromTo', { from: u.from, to: u.to }) : u.to, fmtSize(u.size)].filter(Boolean).join(' · '),
        className: 'st-fw-update',
        control,
        body: () =>
          h(
            'div',
            { class: 'st-sub-pad st-fw-notes' },
            u.summary ? h('div', { class: 'body-strong' }, u.summary) : null,
            ...(u.description || '').split('\n').map((l) => h('div', { class: 'caption text-2' }, l)),
            u.needsReboot ? h('div', { class: 'caption' }, t('update.fw.needsRebootNote')) : null,
          ),
      }),
    );
  }
  const out = [kit.group(t('update.fw.title'), ...rows)];
  if (ups.some((u) => u.requireAc) || fw.updating) out.push(kit.infobar({ kind: 'warning', title: t('update.fw.plugTitle'), message: t('update.fw.plug'), className: 'st-fw-plug' }));
  if (fw.reboot) out.push(kit.infobar({ kind: 'info', title: t('update.fw.restartTitle'), message: t('update.fw.restartDesc'), className: 'st-fw-restart', action: kit.button(t('update.restartNow'), () => pc.shell.reboot().catch(pc.toastError), { primary: true, icon: 'arrow_clockwise' }) }));
  if (fw.error) out.push(kit.infobar({ kind: 'error', message: fw.error, className: 'st-fw-error' }));
  else if (st.error && !fw.refreshing) out.push(kit.infobar({ kind: 'warning', message: st.errorCode === 'ENET' ? t('update.fw.offline') : st.error, className: 'st-fw-error' }));
  return h('div', { class: 'st-fw', dataset: { count: String(ups.length) } }, out);
}
// ---- END firmware ----

async function online(pc) {
  const st = await pc.tryInvoke('net:status');
  return !st || st.connectivity !== 'none';
}

async function check(pc) {
  if (state.phase === 'checking' || state.phase === 'installing') return;
  state.phase = 'checking';
  state.error = null;
  emit();
  try {
    const out = await pc.runAdmin('apt-check', [], 'update.reasonCheck');
    state.packages = parseAptSimulation(out);
    state.lastCheck = Date.now();
    state.phase = null;
    persist(pc);
    pc.tryInvoke('updates:pending'); // fresh lists: the background check's count and badge follow
  } catch (err) {
    state.phase = null;
    if (err.code !== 'ECANCELED') state.error = err.message;
  }
  emit();
}

async function install(pc) {
  if (state.phase) return;
  state.phase = 'installing';
  state.progress = 0;
  state.step = pc.t('update.preparing');
  state.error = null;
  emit();
  const off = pc.api.on('admin:progress', ({ action, line }) => {
    // apt-autoremove: admin.js runs it right after apt-upgrade (old kernels, unused dependencies).
    if (action === 'apt-autoremove') {
      state.step = pc.t('update.cleaning');
      return emit();
    }
    if (action !== 'apt-upgrade') return;
    if (line === 'reboot-required') state.reboot = true;
    const s = parseAptStatus(line);
    if (!s) return;
    if (s.phase === 'error') {
      state.step = s.message;
      return emit();
    }
    state.progress = Math.max(state.progress || 0, s.percent);
    state.step = s.phase === 'download' ? pc.t('update.downloading', { pct: Math.round(s.step) }) : pc.t('update.installingPkg', { pkg: s.pkg || '' });
    emit();
  });
  try {
    const out = await pc.runAdmin('apt-upgrade', [], 'update.reasonInstall');
    if (/^reboot-required$/m.test(out || '')) state.reboot = true;
    state.progress = 100;
    state.packages = [];
    state.lastCheck = Date.now();
    state.phase = 'done';
    persist(pc);
    pc.tryInvoke('updates:clear'); // background check (core/features/update-check.js): badge and count back to 0
    pc.shell.notify({ title: pc.t('update.installedTitle'), body: state.reboot ? pc.t('update.installedReboot') : pc.t('update.installedBody'), appId: 'settings' });
    await seleneLoad(pc); // a new aurora-shell: « Redémarrer la session »
  } catch (err) {
    state.phase = null;
    if (err.code !== 'ECANCELED') state.error = err.message;
  } finally {
    off();
  }
  emit();
}

function when(pc, ms) {
  if (!ms) return pc.t('update.never');
  const d = new Date(ms);
  const today = new Date();
  const time = pc.i18n.formatTime(d, { hour: 'numeric', minute: '2-digit' });
  if (d.toDateString() === today.toDateString()) return pc.t('update.todayAt', { time });
  return `${pc.i18n.formatDate(d, { dateStyle: 'medium' })} ${time}`;
}

async function update(pc) {
  const { h, t, kit, icon } = pc;
  await loadSaved(pc);
  // ---- BEGIN background check (core/features/update-check.js, main/ipc/updates.js) ----
  // Its newer result (from the lists apt-daily refreshes) shows the pending updates without « Rechercher ».
  if (!state.phase) {
    const last = await pc.tryInvoke('updates:last');
    if (last && !last.live && !last.error && last.checkedAt > (state.lastCheck || 0)) {
      state.packages = last.packages.map((p) => ({ ...p, origin: '' }));
      state.lastCheck = last.checkedAt;
    }
  }
  // ---- END background check ----
  const [adm, info, onlineNow] = await Promise.all([pc.adminStatus(), pc.tryInvoke('sys:info'), online(pc)]);
  let isOnline = onlineNow;
  const root = h('div');
  const paint = () => {
    pc.ui.clear(root);
    const grp = groupSelene(state.packages || []);
    const pk = state.packages ? [...(grp.selene ? [{ ...grp.selene.packages[0], security: grp.selene.security }] : []), ...grp.others] : null; // Selene counts once
    const n = pk?.length || 0;
    let title;
    let sub;
    let badge = null;
    if (state.phase === 'checking') {
      title = t('update.checking');
      sub = t('update.checkingDesc');
    } else if (state.phase === 'installing') {
      title = t('update.installing');
      sub = t('update.keepOn');
    } else if (state.phase === 'done') {
      title = state.reboot ? t('update.restartRequired') : t('update.upToDate');
      sub = state.reboot ? t('update.restartDesc') : t('update.lastChecked', { when: when(pc, state.lastCheck) });
      badge = 'ok';
    } else if (pk && n) {
      title = t('update.available', { count: n });
      sub = t('update.lastChecked', { when: when(pc, state.lastCheck) });
      badge = 'pending';
    } else if (pk) {
      title = t('update.upToDate');
      sub = t('update.lastChecked', { when: when(pc, state.lastCheck) });
      badge = 'ok';
    } else {
      title = t('update.unknown');
      sub = t('update.unknownDesc');
    }
    const busy = state.phase === 'checking' || state.phase === 'installing';
    const art = h(
      'div',
      { class: ['st-upd-icon', busy && 'spinning'], 'aria-hidden': 'true' },
      icon('arrow_sync', { size: 26 }),
      badge ? h('span', { class: ['st-upd-badge', badge] }, icon(badge === 'ok' ? 'checkmark_circle' : 'arrow_circle_down', { size: 18, filled: true })) : null,
    );
    const actions = [];
    if (state.reboot && !busy) actions.push(kit.button(t('update.restartNow'), () => pc.shell.reboot().catch(pc.toastError), { primary: true, icon: 'arrow_clockwise' }));
    else if (n && !busy && state.phase !== 'done') actions.push(kit.button(t('update.installNow'), () => install(pc), { primary: true, disabled: !isOnline || !adm?.isAdmin }));
    if (!busy) actions.push(kit.button(t('update.check'), () => check(pc), { primary: !n && !state.reboot, disabled: !isOnline || !adm?.isAdmin }));
    const progress =
      state.phase === 'installing'
        ? h(
            'div',
            { class: 'st-upd-progress' },
            h('div', { class: 'row', style: { justifyContent: 'space-between' } }, h('span', { class: 'caption text-2 ellipsis' }, state.step), h('span', { class: 'caption' }, pc.lang === 'fr' ? `${Math.round(state.progress || 0)} %` : `${Math.round(state.progress || 0)}%`)),
            h('div', { class: 'progress', role: 'progressbar', 'aria-valuemin': '0', 'aria-valuemax': '100', 'aria-valuenow': String(Math.round(state.progress || 0)) }, h('div', { class: 'bar', style: { width: `${state.progress || 0}%` } })),
          )
        : state.phase === 'checking'
          ? h('div', { class: 'st-upd-progress' }, h('div', { class: 'progress indeterminate', role: 'progressbar', 'aria-label': t('update.checking') }, h('div', { class: 'bar' })))
          : null;
    const blocks = [
      h('div', { class: 'st-upd-hero' }, art, h('div', { class: 'st-hero-text' }, h('div', { class: 'st-hero-title' }, title), h('div', { class: 'st-hero-sub' }, sub)), progress, h('div', { class: 'st-hero-actions' }, actions)),
    ];
    if (!isOnline) blocks.push(kit.infobar({ kind: 'warning', title: t('update.offlineTitle'), message: t('update.offline') }));
    if (!adm?.isAdmin) blocks.push(kit.infobar({ kind: 'info', message: t('update.adminOnly') }));
    if (adm?.live) blocks.push(kit.infobar({ kind: 'info', message: t('update.live') }));
    if (state.error) blocks.push(kit.infobar({ kind: 'error', title: t('update.errorTitle'), message: state.error }));
    if (n) {
      blocks.push(
        kit.group(
          null,
          kit.expander({
            icon: 'arrow_download',
            title: t('update.listTitle', { count: n }),
            desc: pk.some((p) => p.security) ? t('update.includesSecurity', { count: pk.filter((p) => p.security).length }) : t('update.listDesc'),
            open: n <= 8,
            body: () =>
              h(
                'div',
                { class: 'st-pkg-list' },
                grp.selene ? seleneRow(pc, grp.selene) : null,
                grp.others.map((p) =>
                  h(
                    'div',
                    { class: 'st-pkg' },
                    h('div', { class: 'row', style: { gap: '8px' } }, h('span', null, p.name), p.security ? h('span', { class: 'st-pill accent' }, t('update.security')) : null),
                    h('span', { class: 'caption text-2 mono' }, p.to),
                    h('span', { class: 'caption text-2' }, p.from ? t('update.fromTo', { from: p.from }) : t('update.newPackage')),
                  ),
                ),
              ),
          }),
        ),
      );
    }
    const selRestart = seleneRestart(pc);
    if (selRestart) blocks.splice(1, 0, selRestart);
    const fwBlock = fwSection(pc);
    if (fwBlock) blocks.push(fwBlock);
    blocks.push(
      kit.group(
        t('update.more'),
        kit.row({ icon: 'history', title: pc.pageTitle('updateHistory'), desc: t('update.historyDesc'), onClick: () => pc.go('updateHistory') }),
        kit.expander({
          icon: 'info',
          title: t('update.advanced'),
          desc: t('update.advancedDesc'),
          body: () =>
            h(
              'div',
              { class: 'st-kv st-sub-pad' },
              [
                [t('about.edition'), info?.osName || 'Selene OS'],
                [t('about.version'), info?.version || pc.env.version || '—'],
                [t('about.build'), info?.buildId || 'dev'],
                [t('about.base'), info?.distro || '—'],
                [t('about.kernel'), info?.kernel || '—'],
                [t('update.source'), t('update.sourceValue')],
              ].flatMap(([k, v]) => [h('div', { class: 'k' }, k), h('div', { class: 'v' }, v)]),
            ),
        }),
      ),
    );
    root.append(...blocks);
  };
  paint();
  listeners.add(paint);
  pc.onDispose(() => listeners.delete(paint));
  fwLoad(pc); // firmware section: read in the background, painted when fwupd answers
  seleneLoad(pc);
  // The network coming back (or going away) enables / disables the buttons without leaving the page.
  pc.on('net:changed', (st) => {
    const now = !st || st.connectivity !== 'none';
    if (now !== isOnline) {
      isOnline = now;
      paint();
    }
  });
  return root;
}

async function updateHistory(pc) {
  const { h, t, kit, icon } = pc;
  let text = null;
  for (const f of ['/var/log/apt/history.log']) {
    text = await pc.api.invoke('fs:readText', f).catch(() => null);
    if (text != null) break;
  }
  const entries = parseAptHistory(text || '').filter((e) => e.upgrade.length || e.install.length || e.remove.length);
  if (!entries.length) return h('div', { class: 'st-empty' }, icon('history', { size: 40 }), h('div', { class: 'body-large' }, t('update.noHistory')), h('div', null, t('update.noHistoryDesc')));
  const fmt = (ms) => (ms ? `${pc.i18n.formatDate(ms, { dateStyle: 'medium' })} ${pc.i18n.formatTime(ms, { hour: 'numeric', minute: '2-digit' })}` : '—');
  return h(
    'div',
    null,
    kit.group(
      t('update.historyTitle'),
      ...entries.slice(0, 60).map((e) => {
        const parts = [];
        if (e.upgrade.length) parts.push(t('update.nUpdated', { count: e.upgrade.length }));
        if (e.install.length) parts.push(t('update.nInstalled', { count: e.install.length }));
        if (e.remove.length) parts.push(t('update.nRemoved', { count: e.remove.length }));
        return kit.expander({
          icon: e.error ? 'error_circle' : 'checkmark_circle',
          title: parts.join(' · '),
          desc: `${fmt(e.start)}${e.requestedBy ? ` · ${e.requestedBy}` : ''}${e.error ? ` · ${t('update.failed')}` : ''}`,
          body: () =>
            h(
              'div',
              { class: 'st-pkg-list' },
              [...e.upgrade.map((p) => [p, 'up']), ...e.install.map((p) => [p, 'in']), ...e.remove.map((p) => [p, 'rm'])].map(([p, k]) =>
                h(
                  'div',
                  { class: 'st-pkg' },
                  h('span', null, p.name),
                  h('span', { class: 'caption text-2 mono' }, p.to || ''),
                  h('span', { class: 'caption text-2' }, k === 'up' ? (p.from ? t('update.fromTo', { from: p.from }) : '') : k === 'in' ? t('update.installedPkg') : t('update.removedPkg')),
                ),
              ),
            ),
        });
      }),
    ),
  );
}

export default { update, updateHistory };
